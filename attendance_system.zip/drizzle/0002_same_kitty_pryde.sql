CREATE TABLE `backups` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`backupName` varchar(255) NOT NULL,
	`backupUrl` text NOT NULL,
	`backupSize` int NOT NULL,
	`recordCount` int NOT NULL,
	`backupType` enum('manual','automatic') NOT NULL DEFAULT 'automatic',
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
	`errorMessage` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `backups_id` PRIMARY KEY(`id`)
);
