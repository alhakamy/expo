import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, CheckCircle2, AlertCircle, Camera, X } from "lucide-react";
import { useLocation } from "wouter";
import { useState, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import jsQR from 'jsqr';

interface AttendanceRecord {
  studentId: number;
  studentName: string;
  class: string;
  status: 'present' | 'absent' | 'late';
  time: string;
}

export default function QuickBarcode() {
  const [, setLocation] = useLocation();
  const [barcodeInput, setBarcodeInput] = useState('');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [todayRecords, setTodayRecords] = useState<AttendanceRecord[]>([]);
  const [today] = useState(new Date().toISOString().split('T')[0]);
  const [lastScannedBarcode, setLastScannedBarcode] = useState<string>('');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [cameraLoading, setCameraLoading] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // API calls
  const { data: students = [] } = trpc.students.list.useQuery();
  const { data: attendanceData = [] } = trpc.attendance.getByDate.useQuery(today);
  const recordAttendanceMutation = trpc.attendance.record.useMutation();

  // Load today's attendance records
  useEffect(() => {
    const records: AttendanceRecord[] = attendanceData.map(a => {
      const student = students.find(s => s.id === a.studentId);
      return {
        studentId: a.studentId,
        studentName: student?.name || 'Unknown',
        class: student?.class || 'Unknown',
        status: a.status,
        time: new Date(a.date).toLocaleTimeString('ar-SA')
      };
    });
    setTodayRecords(records);
  }, [attendanceData, students]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      setCameraLoading(true);
      setCameraError(null);
      
      // طلب الوصول للكاميرا
      const constraints = {
        video: {
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      
      // تأكد من وجود عنصر الفيديو
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        
        // انتظر حتى يتم تحميل الفيديو
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play().catch(err => {
            console.error('Error playing video:', err);
            setCameraError('خطأ في تشغيل الكاميرا');
          });
          setCameraActive(true);
          setCameraLoading(false);
          startBarcodeScanning();
        };
      }
    } catch (error: any) {
      console.error('Error accessing camera:', error);
      setCameraLoading(false);
      
      // رسائل خطأ مفصلة
      if (error.name === 'NotAllowedError') {
        setCameraError('تم رفض إذن الكاميرا. يرجى السماح بالوصول للكاميرا من إعدادات المتصفح.');
      } else if (error.name === 'NotFoundError') {
        setCameraError('لا توجد كاميرا متصلة بجهازك.');
      } else if (error.name === 'NotReadableError') {
        setCameraError('الكاميرا مشغولة أو لا يمكن الوصول إليها.');
      } else {
        setCameraError(`خطأ في الكاميرا: ${error.message || 'حاول مرة أخرى'}`);
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }
    setCameraActive(false);
  };

  const startBarcodeScanning = () => {
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
    }

    scanIntervalRef.current = setInterval(() => {
      if (videoRef.current && canvasRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
        const context = canvasRef.current.getContext('2d');
        if (context) {
          try {
            canvasRef.current.width = videoRef.current.videoWidth;
            canvasRef.current.height = videoRef.current.videoHeight;
            
            // رسم الفيديو على الـ canvas
            context.drawImage(videoRef.current, 0, 0);
            
            // الحصول على بيانات الصورة
            const imageData = context.getImageData(
              0, 0,
              canvasRef.current.width,
              canvasRef.current.height
            );
            
            // تحسين التباين: تحويل إلى رمادي
            const data = imageData.data;
            for (let i = 0; i < data.length; i += 4) {
              const gray = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
              data[i] = gray;
              data[i + 1] = gray;
              data[i + 2] = gray;
            }
            
            // محاولة قراءة الباركود
            const code = jsQR(imageData.data, imageData.width, imageData.height);
            if (code) {
              const barcode = code.data.trim().toLowerCase();
              processBarcodeScanned(barcode);
              stopCamera();
            }
          } catch (err) {
            console.error('Error scanning barcode:', err);
          }
        }
      }
    }, 200);
  };

  const playSuccessSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = 800;
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
    } catch (err) {
      console.error('Error playing sound:', err);
    }
  };

  const handleBarcodeInput = async (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const barcode = barcodeInput.trim().toLowerCase();
      if (barcode) {
        await processBarcodeScanned(barcode);
        setBarcodeInput('');
        barcodeInputRef.current?.focus();
      }
    }
  };

  const processBarcodeScanned = async (barcode: string) => {
    // منع المسح المتكرر
    if (barcode === lastScannedBarcode) {
      return;
    }

    setLastScannedBarcode(barcode);
    setTimeout(() => setLastScannedBarcode(''), 500);

    const student = students.find(s => s.barcode === barcode);

    if (!student) {
      setMessage({ type: 'error', text: 'الباركود غير معروف' });
      setTimeout(() => setMessage(null), 2000);
      return;
    }

    try {
      // التحقق من وجود سجل حضور اليوم
      const existingRecord = todayRecords.find(r => r.studentId === student.id);
      const newStatus = existingRecord?.status === 'present' ? 'absent' : 'present';

      await recordAttendanceMutation.mutateAsync({
        studentId: student.id,
        date: today,
        status: newStatus,
      });

      playSuccessSound();

      // تحديث السجلات المحلية
      const updatedRecords = todayRecords.filter(r => r.studentId !== student.id);
      updatedRecords.push({
        studentId: student.id,
        studentName: student.name,
        class: student.class,
        status: newStatus,
        time: new Date().toLocaleTimeString('ar-SA')
      });
      setTodayRecords(updatedRecords);

      const statusText = newStatus === 'present' ? 'حاضر' : 'غائب';
      setMessage({ 
        type: 'success', 
        text: `${student.name} - ${statusText}` 
      });
      setTimeout(() => setMessage(null), 2000);
    } catch (error) {
      console.error('Error recording attendance:', error);
      setMessage({ type: 'error', text: 'خطأ في حفظ البيانات' });
      setTimeout(() => setMessage(null), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <Button
          variant="outline"
          onClick={() => setLocation('/')}
          className="mb-6 flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          العودة
        </Button>

        {/* Camera Modal */}
        {cameraActive && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden">
              <div className="bg-gradient-to-r from-blue-600 to-cyan-600 p-4 flex items-center justify-between">
                <h2 className="text-white font-bold text-lg">مسح الباركود</h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={stopCamera}
                  className="text-white hover:bg-white hover:bg-opacity-20"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
              <div className="p-6 space-y-4">
                <div className="relative bg-black rounded-xl overflow-hidden shadow-lg">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-96 object-cover"
                    style={{ transform: 'scaleX(-1)' }}
                  />
                  <canvas ref={canvasRef} className="hidden" />
                  <div className="absolute inset-0 border-4 border-green-400 rounded-xl pointer-events-none"></div>
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
                    <div className="text-5xl mb-2 animate-pulse">📷</div>
                  </div>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-800 text-center font-semibold">
                    الكاميرا في وضع الاستعداد<br/>
                    <span className="text-xs">سيتم قراءة الباركود تلقائياً</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Input Card */}
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">التحضير السريع بالباركود</CardTitle>
                <CardDescription>أدخل رقم الباركود لتسجيل الحضور</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {message && (
                  <Alert className={`${message.type === 'success' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                    {message.type === 'success' ? (
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                    ) : (
                      <AlertCircle className="h-4 w-4 text-red-600" />
                    )}
                    <AlertDescription className={message.type === 'success' ? 'text-green-800' : 'text-red-800'}>
                      {message.text}
                    </AlertDescription>
                  </Alert>
                )}

                {cameraError && (
                  <Alert className="bg-red-50 border-red-200">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-800">
                      {cameraError}
                    </AlertDescription>
                  </Alert>
                )}

                {!cameraActive && (
                  <>
                    <div>
                      <label className="block text-sm font-medium mb-3">رقم الباركود</label>
                      <input
                        ref={barcodeInputRef}
                        type="text"
                        value={barcodeInput}
                        onChange={(e) => setBarcodeInput(e.target.value)}
                        onKeyDown={handleBarcodeInput}
                        placeholder="مثال: stu1"
                        className="w-full p-4 text-lg border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        autoFocus
                      />
                      <p className="text-sm text-gray-500 mt-2">اضغط Enter لتسجيل الحضور</p>
                    </div>
                    <Button
                      onClick={startCamera}
                      disabled={cameraLoading}
                      className="w-full flex items-center justify-center gap-2 bg-cyan-600 hover:bg-cyan-700 disabled:opacity-50"
                    >
                      <Camera className="w-4 h-4" />
                      {cameraLoading ? 'جاري فتح الكاميرا...' : 'فتح الكاميرا'}
                    </Button>
                  </>
                )}

                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-800">
                    <strong>عدد الطلاب المسجلين اليوم:</strong> {todayRecords.length}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Stats Card */}
          <div>
            <Card className="shadow-lg h-full">
              <CardHeader>
                <CardTitle className="text-lg">ملخص اليوم</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">الحاضرون</p>
                  <p className="text-3xl font-bold text-green-600">
                    {todayRecords.filter(r => r.status === 'present').length}
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">الغائبون</p>
                  <p className="text-3xl font-bold text-red-600">
                    {todayRecords.filter(r => r.status === 'absent').length}
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">إجمالي الطلاب</p>
                  <p className="text-3xl font-bold text-blue-600">
                    {students.length}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Today's Records */}
        {todayRecords.length > 0 && (
          <Card className="mt-6 shadow-lg">
            <CardHeader>
              <CardTitle>سجلات اليوم</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {todayRecords.map(record => (
                  <div key={record.studentId} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-semibold">{record.studentName}</p>
                      <p className="text-sm text-gray-600">{record.class}</p>
                    </div>
                    <div className="text-right">
                      <p className={`font-semibold ${record.status === 'present' ? 'text-green-600' : 'text-red-600'}`}>
                        {record.status === 'present' ? 'حاضر' : 'غائب'}
                      </p>
                      <p className="text-sm text-gray-600">{record.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
