import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Printer, Download, Calendar } from 'lucide-react';
import { useLocation } from 'wouter';

interface Student {
  id: string;
  name: string;
  class: string;
  barcode: string;
}

interface AttendanceRecord {
  date: string;
  classname: string;
  attendance: Record<string, 'present' | 'absent'>;
}

export default function DailyAbsenceReport({
  students,
  attendanceRecords
}: {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
}) {
  const [, setLocation] = useLocation();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedClass, setSelectedClass] = useState<string>('');

  const classes = Array.from(new Set(students.map(s => s.class)));
  
  const getAbsentStudents = () => {
    if (!selectedClass) return [];
    
    const record = attendanceRecords.find(r => r.date === selectedDate && r.classname === selectedClass);
    const classStudents = students.filter(s => s.class === selectedClass);
    
    if (!record) {
      return classStudents;
    }
    
    return classStudents.filter(s => record.attendance[s.id] === 'absent' || !record.attendance[s.id]);
  };

  const handlePrint = () => {
    const absentStudents = getAbsentStudents();
    const printWindow = window.open('', '', 'height=600,width=800');
    
    if (printWindow) {
      const dateObj = new Date(selectedDate);
      const formattedDate = dateObj.toLocaleDateString('ar-SA', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });

      const html = `
        <!DOCTYPE html>
        <html dir="rtl">
        <head>
          <meta charset="UTF-8">
          <title>تقرير الغياب اليومي</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              margin: 20px;
              direction: rtl;
            }
            .header {
              text-align: center;
              margin-bottom: 30px;
              border-bottom: 2px solid #333;
              padding-bottom: 10px;
            }
            .header h1 {
              margin: 0;
              font-size: 24px;
            }
            .header p {
              margin: 5px 0;
              font-size: 14px;
            }
            .info {
              margin: 20px 0;
              font-size: 14px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 20px;
            }
            th, td {
              border: 1px solid #ddd;
              padding: 12px;
              text-align: right;
            }
            th {
              background-color: #f0f0f0;
              font-weight: bold;
            }
            tr:nth-child(even) {
              background-color: #f9f9f9;
            }
            .footer {
              margin-top: 30px;
              text-align: center;
              font-size: 12px;
              color: #666;
            }
            .no-data {
              text-align: center;
              padding: 20px;
              color: #666;
              font-size: 16px;
            }
            @media print {
              body {
                margin: 0;
              }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>تقرير الغياب اليومي</h1>
            <p>المدرسة / المؤسسة التعليمية</p>
          </div>
          
          <div class="info">
            <p><strong>التاريخ:</strong> ${formattedDate}</p>
            <p><strong>الصف:</strong> ${selectedClass}</p>
            <p><strong>عدد الغائبين:</strong> ${absentStudents.length}</p>
          </div>

          ${absentStudents.length > 0 ? `
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>اسم الطالب</th>
                  <th>رقم الطالب</th>
                </tr>
              </thead>
              <tbody>
                ${absentStudents.map((student, index) => `
                  <tr>
                    <td>${index + 1}</td>
                    <td>${student.name}</td>
                    <td>${student.barcode}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          ` : `
            <div class="no-data">
              لا توجد غيابات في هذا التاريخ
            </div>
          `}

          <div class="footer">
            <p>تم إنشاء التقرير بواسطة نظام التحضير الإلكتروني</p>
            <p>${new Date().toLocaleString('ar-SA')}</p>
          </div>
        </body>
        </html>
      `;
      
      printWindow.document.write(html);
      printWindow.document.close();
      setTimeout(() => printWindow.print(), 250);
    }
  };

  const handleDownload = () => {
    const absentStudents = getAbsentStudents();
    const dateObj = new Date(selectedDate);
    const formattedDate = dateObj.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    let csvContent = 'data:text/csv;charset=utf-8,\uFEFF';
    csvContent += `تقرير الغياب اليومي\n`;
    csvContent += `التاريخ: ${formattedDate}\n`;
    csvContent += `الصف: ${selectedClass}\n`;
    csvContent += `عدد الغائبين: ${absentStudents.length}\n\n`;
    csvContent += `#,اسم الطالب,رقم الطالب\n`;
    
    absentStudents.forEach((student, index) => {
      csvContent += `${index + 1},"${student.name}","${student.barcode}"\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `تقرير_الغياب_${selectedDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const absentStudents = getAbsentStudents();

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <Button variant="ghost" onClick={() => setLocation('/')} className="mb-6">
          <ArrowLeft className="ml-2" />
          العودة للرئيسية
        </Button>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl md:text-3xl flex items-center gap-3">
              <Calendar className="w-6 h-6 md:w-8 md:h-8 text-red-600" />
              تقرير الغياب اليومي
            </CardTitle>
            <CardDescription className="text-sm md:text-base">
              عرض وطباعة تقرير الغياب لكل صف
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">اختر التاريخ</label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-lg text-sm md:text-base"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">اختر الصف</label>
                <select
                  value={selectedClass}
                  onChange={(e) => setSelectedClass(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-lg text-sm md:text-base"
                >
                  <option value="">-- اختر الصف --</option>
                  {classes.map(cls => (
                    <option key={cls} value={cls}>{cls}</option>
                  ))}
                </select>
              </div>
            </div>

            {selectedClass && (
              <>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm md:text-base">
                    <strong>التاريخ:</strong> {new Date(selectedDate).toLocaleDateString('ar-SA', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                  <p className="text-sm md:text-base">
                    <strong>الصف:</strong> {selectedClass}
                  </p>
                  <p className="text-sm md:text-base">
                    <strong>عدد الغائبين:</strong> <span className="text-red-600 font-bold">{absentStudents.length}</span>
                  </p>
                </div>

                <div className="flex gap-2 flex-wrap">
                  <Button onClick={handlePrint} className="flex-1 bg-blue-600 hover:bg-blue-700 text-sm md:text-base">
                    <Printer className="ml-2 w-4 h-4" />
                    طباعة
                  </Button>
                  <Button onClick={handleDownload} className="flex-1 bg-green-600 hover:bg-green-700 text-sm md:text-base">
                    <Download className="ml-2 w-4 h-4" />
                    تحميل CSV
                  </Button>
                </div>

                {absentStudents.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead className="bg-red-100">
                        <tr>
                          <th className="border border-gray-300 p-3 text-right text-sm font-semibold">#</th>
                          <th className="border border-gray-300 p-3 text-right text-sm font-semibold">اسم الطالب</th>
                          <th className="border border-gray-300 p-3 text-right text-sm font-semibold">الصف</th>
                          <th className="border border-gray-300 p-3 text-right text-sm font-semibold">رقم الطالب</th>
                        </tr>
                      </thead>
                      <tbody>
                        {absentStudents.map((student, index) => (
                          <tr key={student.id} className="hover:bg-red-50">
                            <td className="border border-gray-300 p-3 text-sm">{index + 1}</td>
                            <td className="border border-gray-300 p-3 text-sm font-medium">{student.name}</td>
                            <td className="border border-gray-300 p-3 text-sm">{student.class}</td>
                            <td className="border border-gray-300 p-3 text-sm font-mono">{student.barcode}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-8 text-center">
                    <p className="text-green-800 font-medium text-sm md:text-base">
                      ✓ لا توجد غيابات في هذا التاريخ
                    </p>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
