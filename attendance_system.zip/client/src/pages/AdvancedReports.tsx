import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Download, Filter, BarChart3 } from 'lucide-react';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import * as XLSX from 'xlsx';

export default function AdvancedReports() {
  const [, setLocation] = useLocation();
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [selectedStudent, setSelectedStudent] = useState<number | null>(null);

  // API calls
  const { data: students = [] } = trpc.students.list.useQuery();
  const { data: allAttendance = [] } = trpc.attendance.getByDate.useQuery(new Date().toISOString().split('T')[0]);

  const classes = Array.from(new Set(students.map(s => s.class)));
  const classStudents = selectedClass ? students.filter(s => s.class === selectedClass) : students;

  // Filter attendance records
  const filteredAttendance = useMemo(() => {
    let filtered = allAttendance;

    if (selectedClass) {
      const classStudentIds = students
        .filter(s => s.class === selectedClass)
        .map(s => s.id);
      filtered = filtered.filter(a => classStudentIds.includes(a.studentId));
    }

    if (startDate) {
      filtered = filtered.filter(a => new Date(a.date) >= new Date(startDate));
    }

    if (endDate) {
      filtered = filtered.filter(a => new Date(a.date) <= new Date(endDate));
    }

    if (selectedStudent) {
      filtered = filtered.filter(a => a.studentId === selectedStudent);
    }

    return filtered;
  }, [allAttendance, selectedClass, startDate, endDate, selectedStudent, students]);

  // Calculate statistics
  const statistics = useMemo(() => {
    const stats: Record<number, { present: number; absent: number; total: number }> = {};

    classStudents.forEach(student => {
      stats[student.id] = { present: 0, absent: 0, total: 0 };
    });

    filteredAttendance.forEach(record => {
      if (stats[record.studentId]) {
        stats[record.studentId].total++;
        if (record.status === 'present') {
          stats[record.studentId].present++;
        } else {
          stats[record.studentId].absent++;
        }
      }
    });

    return stats;
  }, [filteredAttendance, classStudents]);

  const exportToExcel = () => {
    const data = classStudents.map(student => ({
      'اسم الطالب': student.name,
      'الصف': student.class,
      'عدد الحضور': statistics[student.id]?.present || 0,
      'عدد الغياب': statistics[student.id]?.absent || 0,
      'إجمالي الأيام': statistics[student.id]?.total || 0,
      'نسبة الحضور': statistics[student.id]?.total ? 
        `${((statistics[student.id].present / statistics[student.id].total) * 100).toFixed(2)}%` : 
        '0%'
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'التقرير');
    XLSX.writeFile(workbook, `تقرير_الحضور_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <Button variant="ghost" onClick={() => setLocation('/')} className="mb-6">
          <ArrowLeft className="ml-2" />
          العودة للرئيسية
        </Button>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-2xl md:text-3xl flex items-center gap-3">
              <BarChart3 className="w-6 h-6 md:w-8 md:h-8 text-purple-600" />
              التقارير المتقدمة
            </CardTitle>
            <CardDescription className="text-sm md:text-base">
              عرض وتصفية وتحليل سجلات الحضور والغياب
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Filters */}
            <div className="bg-gray-50 p-4 rounded-lg space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Filter className="w-5 h-5 text-gray-600" />
                <h3 className="font-semibold">خيارات التصفية</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">الصف</label>
                  <select
                    value={selectedClass}
                    onChange={(e) => {
                      setSelectedClass(e.target.value);
                      setSelectedStudent(null);
                    }}
                    className="w-full p-2 border border-gray-300 rounded-lg text-sm"
                  >
                    <option value="">-- جميع الصفوف --</option>
                    {classes.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">الطالب</label>
                  <select
                    value={selectedStudent || ''}
                    onChange={(e) => setSelectedStudent(e.target.value ? parseInt(e.target.value) : null)}
                    className="w-full p-2 border border-gray-300 rounded-lg text-sm"
                  >
                    <option value="">-- جميع الطلاب --</option>
                    {classStudents.map(student => (
                      <option key={student.id} value={student.id}>{student.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">من التاريخ</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg text-sm"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">إلى التاريخ</label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg text-sm"
                  />
                </div>
              </div>

              <Button
                onClick={exportToExcel}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                <Download className="w-4 h-4 ml-2" />
                تحميل التقرير (Excel)
              </Button>
            </div>

            {/* Results Table */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="border border-gray-300 px-4 py-2 text-right text-sm font-semibold">#</th>
                    <th className="border border-gray-300 px-4 py-2 text-right text-sm font-semibold">اسم الطالب</th>
                    <th className="border border-gray-300 px-4 py-2 text-right text-sm font-semibold">الصف</th>
                    <th className="border border-gray-300 px-4 py-2 text-right text-sm font-semibold">الحضور</th>
                    <th className="border border-gray-300 px-4 py-2 text-right text-sm font-semibold">الغياب</th>
                    <th className="border border-gray-300 px-4 py-2 text-right text-sm font-semibold">الإجمالي</th>
                    <th className="border border-gray-300 px-4 py-2 text-right text-sm font-semibold">نسبة الحضور</th>
                  </tr>
                </thead>
                <tbody>
                  {classStudents.map((student, index) => {
                    const stat = statistics[student.id] || { present: 0, absent: 0, total: 0 };
                    const attendanceRate = stat.total > 0 ? ((stat.present / stat.total) * 100).toFixed(2) : '0';
                    const rateColor = parseFloat(attendanceRate) >= 80 ? 'text-green-600' : 
                                     parseFloat(attendanceRate) >= 60 ? 'text-yellow-600' : 'text-red-600';

                    return (
                      <tr key={student.id} className="hover:bg-gray-50">
                        <td className="border border-gray-300 px-4 py-2 text-sm">{index + 1}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm font-medium">{student.name}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm">{student.class}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm text-green-600 font-medium">{stat.present}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm text-red-600 font-medium">{stat.absent}</td>
                        <td className="border border-gray-300 px-4 py-2 text-sm">{stat.total}</td>
                        <td className={`border border-gray-300 px-4 py-2 text-sm font-medium ${rateColor}`}>
                          {attendanceRate}%
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {classStudents.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                لا توجد بيانات للعرض
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
