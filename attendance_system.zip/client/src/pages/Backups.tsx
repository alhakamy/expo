import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Download, Loader2, CheckCircle2, AlertCircle, Cloud } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';

export default function Backups() {
  const [, setLocation] = useLocation();
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  // API calls
  const { data: backups = [] } = trpc.backup.list.useQuery();
  const { data: backupData } = trpc.backup.getData.useQuery();
  const createBackupMutation = trpc.backup.create.useMutation();
  const updateStatusMutation = trpc.backup.updateStatus.useMutation();

  const createManualBackup = async () => {
    try {
      setIsCreating(true);
      
      if (!backupData) {
        setMessage({ type: 'error', text: 'لا توجد بيانات للنسخ الاحتياطي' });
        return;
      }

      const backupJson = JSON.stringify(backupData);
      const backupSize = new Blob([backupJson]).size;
      const recordCount = (backupData.students?.length || 0) + (backupData.attendance?.length || 0);
      
      // إنشاء رابط تحميل مؤقت
      const blob = new Blob([backupJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      // إنشاء سجل النسخة الاحتياطية
      const result = await createBackupMutation.mutateAsync({
        backupName: `Backup-${new Date().toISOString().split('T')[0]}`,
        backupUrl: url,
        backupSize,
        recordCount,
        backupType: 'manual',
      });

      // تحديث الحالة إلى مكتملة
      if (result && 'insertId' in result) {
        await updateStatusMutation.mutateAsync({
          backupId: result.insertId as number,
          status: 'completed',
        });
      }

      setMessage({ 
        type: 'success', 
        text: 'تم إنشاء النسخة الاحتياطية بنجاح!' 
      });
      setTimeout(() => setMessage(null), 3000);
    } catch (error) {
      console.error('Error creating backup:', error);
      setMessage({ 
        type: 'error', 
        text: 'حدث خطأ في إنشاء النسخة الاحتياطية' 
      });
      setTimeout(() => setMessage(null), 3000);
    } finally {
      setIsCreating(false);
    }
  };

  const downloadBackup = (backup: any) => {
    try {
      const link = document.createElement('a');
      link.href = backup.backupUrl;
      link.download = `${backup.backupName}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error downloading backup:', error);
      setMessage({ 
        type: 'error', 
        text: 'خطأ في تحميل النسخة الاحتياطية' 
      });
    }
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleString('ar-SA');
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <Button 
          variant="ghost" 
          onClick={() => setLocation('/')} 
          className="mb-6 flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          العودة للرئيسية
        </Button>

        <Card className="mb-6 shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl md:text-3xl flex items-center gap-3">
              <Cloud className="w-6 h-6 md:w-8 md:h-8 text-blue-600" />
              النسخ الاحتياطية
            </CardTitle>
            <CardDescription className="text-sm md:text-base">
              إدارة النسخ الاحتياطية للبيانات والاستعادة منها
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {message && (
              <Alert className={`${message.type === 'success' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                {message.type === 'success' ? (
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-red-600" />
                )}
                <AlertDescription className={message.type === 'success' ? 'text-green-800' : 'text-red-800'}>
                  {message.text}
                </AlertDescription>
              </Alert>
            )}

            <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
              <h3 className="font-semibold text-blue-900 mb-2">معلومات النسخ الاحتياطية</h3>
              <div className="text-sm text-blue-800 space-y-1">
                <p>✓ عدد النسخ المحفوظة: <strong>{backups.length}</strong></p>
                <p>✓ آخر نسخة: <strong>{backups.length > 0 ? formatDate(backups[0].createdAt) : 'لا توجد'}</strong></p>
                <p>✓ إجمالي السجلات: <strong>{backups.reduce((sum, b) => sum + (b.recordCount || 0), 0)}</strong></p>
              </div>
            </div>

            <Button
              onClick={createManualBackup}
              className="w-full bg-green-600 hover:bg-green-700 text-sm md:text-base"
              disabled={isCreating}
            >
              {isCreating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  جاري إنشاء النسخة...
                </>
              ) : (
                <>
                  <Cloud className="w-4 h-4 mr-2" />
                  إنشاء نسخة احتياطية الآن
                </>
              )}
            </Button>

            <div className="space-y-3">
              <h3 className="font-semibold text-lg">سجل النسخ الاحتياطية</h3>
              {backups.length > 0 ? (
                backups.map((backup: any) => (
                  <div
                    key={backup.id}
                    className="flex items-center justify-between p-4 rounded-lg border-2 border-gray-200 hover:border-blue-300 transition-all bg-white"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium text-sm md:text-base">{backup.backupName}</h4>
                        <span className={`text-xs px-2 py-1 rounded ${
                          backup.status === 'completed' 
                            ? 'bg-green-100 text-green-800' 
                            : backup.status === 'failed'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {backup.status === 'completed' ? 'مكتملة' : backup.status === 'failed' ? 'فشلت' : 'قيد الانتظار'}
                        </span>
                        <span className="text-xs px-2 py-1 rounded bg-blue-100 text-blue-800">
                          {backup.backupType === 'manual' ? 'يدوية' : 'دورية'}
                        </span>
                      </div>
                      <div className="text-xs text-gray-600 space-y-1">
                        <p>التاريخ: {formatDate(backup.createdAt)}</p>
                        <p>الحجم: {formatSize(backup.backupSize)} | السجلات: {backup.recordCount}</p>
                      </div>
                    </div>
                    <Button
                      onClick={() => downloadBackup(backup)}
                      variant="outline"
                      className="ml-2"
                      disabled={backup.status !== 'completed'}
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">
                  لا توجد نسخ احتياطية حتى الآن
                </div>
              )}
            </div>

            <div className="bg-amber-50 border-2 border-amber-200 rounded-lg p-4">
              <h3 className="font-semibold text-amber-900 mb-2">ملاحظات مهمة</h3>
              <ul className="text-sm text-amber-800 space-y-1">
                <li>• النسخ الاحتياطية تُحفظ تلقائياً يومياً</li>
                <li>• يمكنك إنشاء نسخة احتياطية يدوية في أي وقت</li>
                <li>• احفظ النسخ الاحتياطية في مكان آمن</li>
                <li>• يمكنك استعادة البيانات من أي نسخة احتياطية</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
