import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Download } from 'lucide-react';
import { useLocation } from 'wouter';
import * as XLSX from 'xlsx';

interface Student {
  id: string;
  name: string;
  class: string;
  barcode: string;
}

interface AttendanceRecord {
  date: string;
  classname: string;
  attendance: Record<string, 'present' | 'absent'>;
}

export default function MonthlyStatistics({
  students,
  attendanceRecords
}: {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
}) {
  const [, setLocation] = useLocation();
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [selectedMonth, setSelectedMonth] = useState<string>(new Date().toISOString().slice(0, 7));

  const classes = Array.from(new Set(students.map(s => s.class)));
  const classStudents = selectedClass ? students.filter(s => s.class === selectedClass) : [];

  // Filter records for selected month and class
  const monthRecords = attendanceRecords.filter(r => {
    const recordMonth = r.date.slice(0, 7);
    return recordMonth === selectedMonth && r.classname === selectedClass;
  });

  // Calculate statistics
  const statistics = classStudents.map(student => {
    const absences = monthRecords.filter(r => r.attendance[student.id] === 'absent').length;
    const presences = monthRecords.filter(r => r.attendance[student.id] === 'present').length;
    return {
      student,
      absences,
      presences,
      total: monthRecords.length
    };
  });

  const exportToExcel = () => {
    if (!selectedClass) return;

    const data = statistics.map(stat => ({
      'اسم الطالب': stat.student.name,
      'الصف': stat.student.class,
      'الباركود': stat.student.barcode,
      'عدد أيام الحضور': stat.presences,
      'عدد أيام الغياب': stat.absences,
      'إجمالي الأيام': stat.total
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'الإحصائيات');
    XLSX.writeFile(workbook, `احصائيات_${selectedClass}_${selectedMonth}.xlsx`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-8">
      <div className="max-w-6xl mx-auto">
        <Button variant="ghost" onClick={() => setLocation('/')} className="mb-6">
          <ArrowLeft className="ml-2" />
          العودة للرئيسية
        </Button>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-3xl">الإحصائيات الشهرية</CardTitle>
            <CardDescription className="text-base">
              عرض إحصائيات الحضور والغياب لكل طالب
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">اختر الصف</label>
                <select
                  value={selectedClass}
                  onChange={(e) => setSelectedClass(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-lg"
                >
                  <option value="">-- اختر الصف --</option>
                  {classes.map(cls => (
                    <option key={cls} value={cls}>{cls}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">اختر الشهر</label>
                <input
                  type="month"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>

            {selectedClass && statistics.length > 0 && (
              <>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">#</th>
                        <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">اسم الطالب</th>
                        <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">الباركود</th>
                        <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">أيام الحضور</th>
                        <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">أيام الغياب</th>
                        <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">إجمالي الأيام</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {statistics.map((stat, index) => (
                        <tr key={stat.student.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3 text-sm text-gray-600">{index + 1}</td>
                          <td className="px-4 py-3 text-sm font-medium text-gray-900">{stat.student.name}</td>
                          <td className="px-4 py-3 text-sm text-gray-600 font-mono">{stat.student.barcode}</td>
                          <td className="px-4 py-3 text-sm text-green-600 font-medium">{stat.presences}</td>
                          <td className="px-4 py-3 text-sm text-red-600 font-medium">{stat.absences}</td>
                          <td className="px-4 py-3 text-sm text-gray-600">{stat.total}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <Button onClick={exportToExcel} className="w-full bg-purple-600 hover:bg-purple-700">
                  <Download className="ml-2 w-4 h-4" />
                  تصدير إلى Excel
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
