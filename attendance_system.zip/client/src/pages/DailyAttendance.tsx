import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, CheckCircle2, XCircle, Loader2, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';

export default function DailyAttendance() {
  const [, setLocation] = useLocation();
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [attendance, setAttendance] = useState<Record<number, 'present' | 'absent'>>({});
  const [saveStatus, setSaveStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [savingStudents, setSavingStudents] = useState<number[]>([]);
  const [today] = useState(new Date().toISOString().split('T')[0]);

  // API calls
  const { data: students = [] } = trpc.students.list.useQuery();
  const { data: todayAttendance = [] } = trpc.attendance.getByDate.useQuery(today);
  const recordAttendanceMutation = trpc.attendance.record.useMutation();

  const classes = Array.from(new Set(students.map(s => s.class)));
  const classStudents = selectedClass ? students.filter(s => s.class === selectedClass) : [];

  // Load today's attendance
  useEffect(() => {
    const classAttendance: Record<number, 'present' | 'absent'> = {};
    classStudents.forEach(student => {
      const record = todayAttendance.find(a => a.studentId === student.id);
      classAttendance[student.id] = record?.status === 'present' ? 'present' : 'absent';
    });
    setAttendance(classAttendance);
  }, [selectedClass, todayAttendance, classStudents]);

  const toggleAttendance = async (studentId: number) => {
    try {
      // تحديث الحالة محلياً
      const newStatus = attendance[studentId] === 'present' ? 'absent' : 'present';
      setAttendance(prev => ({
        ...prev,
        [studentId]: newStatus
      }));

      // حفظ فوري
      setSavingStudents(prev => [...prev, studentId]);
      
      await recordAttendanceMutation.mutateAsync({
        studentId: studentId,
        date: today,
        status: newStatus,
      });

      setSavingStudents(prev => prev.filter(id => id !== studentId));

      setSaveStatus({ 
        type: 'success', 
        message: 'تم تسجيل الحضور بنجاح' 
      });
      setTimeout(() => setSaveStatus(null), 2000);
    } catch (error) {
      console.error('Error saving attendance:', error);
      setSavingStudents(prev => prev.filter(id => id !== studentId));
      setSaveStatus({ 
        type: 'error', 
        message: 'خطأ في حفظ البيانات' 
      });
      setTimeout(() => setSaveStatus(null), 3000);
    }
  };

  const saveAllAttendance = async () => {
    try {
      setSaveStatus(null);
      for (const student of classStudents) {
        const status = attendance[student.id] || 'absent';
        await recordAttendanceMutation.mutateAsync({
          studentId: student.id,
          date: today,
          status: status,
        });
      }
      setSaveStatus({ 
        type: 'success', 
        message: 'تم حفظ التحضير بنجاح!' 
      });
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (error) {
      console.error('Error saving attendance:', error);
      setSaveStatus({ 
        type: 'error', 
        message: 'خطأ في حفظ البيانات' 
      });
      setTimeout(() => setSaveStatus(null), 3000);
    }
  };

  const markAllPresent = async () => {
    const newAttendance: Record<number, 'present' | 'absent'> = {};
    classStudents.forEach(student => {
      newAttendance[student.id] = 'present';
    });
    setAttendance(newAttendance);
    
    // حفظ الجميع
    try {
      for (const student of classStudents) {
        await recordAttendanceMutation.mutateAsync({
          studentId: student.id,
          date: today,
          status: 'present',
        });
      }
      setSaveStatus({ 
        type: 'success', 
        message: 'تم تسجيل الجميع حاضرين' 
      });
      setTimeout(() => setSaveStatus(null), 2000);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const markAllAbsent = async () => {
    const newAttendance: Record<number, 'present' | 'absent'> = {};
    classStudents.forEach(student => {
      newAttendance[student.id] = 'absent';
    });
    setAttendance(newAttendance);
    
    // حفظ الجميع
    try {
      for (const student of classStudents) {
        await recordAttendanceMutation.mutateAsync({
          studentId: student.id,
          date: today,
          status: 'absent',
        });
      }
      setSaveStatus({ 
        type: 'success', 
        message: 'تم تسجيل الجميع غائبين' 
      });
      setTimeout(() => setSaveStatus(null), 2000);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const presentCount = Object.values(attendance).filter(s => s === 'present').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <Button 
          variant="ghost" 
          onClick={() => setLocation('/')} 
          className="mb-6 flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          العودة للرئيسية
        </Button>

        <Card className="mb-6 shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl md:text-3xl flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 md:w-8 md:h-8 text-green-600" />
              التحضير اليومي
            </CardTitle>
            <CardDescription className="text-sm md:text-base">
              سجل حضور وغياب الطلاب لتاريخ اليوم: {today}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">اختر الصف</label>
              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="w-full p-3 border-2 border-gray-300 rounded-lg text-sm md:text-base focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="">-- اختر الصف --</option>
                {classes.map(cls => (
                  <option key={cls} value={cls}>{cls}</option>
                ))}
              </select>
            </div>

            {saveStatus && (
              <Alert className={`${
                saveStatus.type === 'success' 
                  ? 'bg-green-50 border-green-200' 
                  : 'bg-red-50 border-red-200'
              }`}>
                {saveStatus.type === 'success' ? (
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-red-600" />
                )}
                <AlertDescription className={
                  saveStatus.type === 'success' 
                    ? 'text-green-800' 
                    : 'text-red-800'
                }>
                  {saveStatus.message}
                </AlertDescription>
              </Alert>
            )}

            {selectedClass && (
              <>
                <div className="flex gap-2 flex-wrap">
                  <Button
                    onClick={markAllPresent}
                    variant="outline"
                    className="flex-1 text-sm border-green-300 text-green-700 hover:bg-green-50"
                  >
                    الكل حاضرون
                  </Button>
                  <Button
                    onClick={markAllAbsent}
                    variant="outline"
                    className="flex-1 text-sm border-red-300 text-red-700 hover:bg-red-50"
                  >
                    الكل غائبون
                  </Button>
                </div>

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  <h3 className="font-semibold text-lg sticky top-0 bg-white py-2 z-10">
                    الطلاب ({presentCount}/{classStudents.length})
                  </h3>
                  {classStudents.length > 0 ? (
                    classStudents.map(student => (
                      <div
                        key={student.id}
                        className={`flex items-center justify-between p-3 rounded-lg border-2 text-sm md:text-base transition-all ${
                          attendance[student.id] === 'present'
                            ? 'bg-green-50 border-green-300 cursor-pointer hover:bg-green-100'
                            : 'bg-red-50 border-red-300 cursor-pointer hover:bg-red-100'
                        } ${savingStudents.includes(student.id) ? 'opacity-60' : ''}`}
                        onClick={() => !savingStudents.includes(student.id) && toggleAttendance(student.id)}
                      >
                        <span className="font-medium flex-1">{student.name}</span>
                        <div className="flex items-center gap-2">
                          {savingStudents.includes(student.id) ? (
                            <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
                          ) : attendance[student.id] === 'present' ? (
                            <CheckCircle2 className="w-5 h-5 text-green-600" />
                          ) : (
                            <XCircle className="w-5 h-5 text-red-600" />
                          )}
                          <span className="text-xs md:text-sm font-medium">
                            {savingStudents.includes(student.id) ? 'جاري...' : (attendance[student.id] === 'present' ? 'حاضر' : 'غائب')}
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      لا توجد طلاب في هذا الصف
                    </div>
                  )}
                </div>

                <Button
                  onClick={saveAllAttendance}
                  className="w-full bg-green-600 hover:bg-green-700 text-sm md:text-base"
                  disabled={recordAttendanceMutation.isPending || savingStudents.length > 0}
                >
                  {recordAttendanceMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      جاري الحفظ...
                    </>
                  ) : (
                    'حفظ التحضير'
                  )}
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
