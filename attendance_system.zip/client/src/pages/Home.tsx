import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, ClipboardCheck, BarChart3, Camera, AlertCircle, Printer, LogOut, TrendingUp, Zap, Settings, Cloud } from "lucide-react";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-8">
        <div className="text-center max-w-md">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">نظام التحضير الإلكتروني</h1>
          <p className="text-xl text-gray-600 mb-8">يرجى تسجيل الدخول للمتابعة</p>
          <Button size="lg" onClick={() => window.location.href = getLoginUrl()}>
            تسجيل الدخول
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h1 className="text-5xl font-bold text-gray-800 mb-2">نظام التحضير الإلكتروني</h1>
            <p className="text-xl text-gray-600">إدارة حضور الطلاب بسهولة وفعالية</p>
          </div>
          <div className="text-right">
            <p className="text-gray-700 font-medium mb-2">مرحباً {user?.name || 'المستخدم'}</p>
            <Button variant="outline" onClick={() => logout()} className="flex items-center gap-2">
              <LogOut className="w-4 h-4" />
              تسجيل الخروج
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2" onClick={() => setLocation('/upload')}>
            <CardHeader className="text-center">
              <div className="mx-auto bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Upload className="w-8 h-8 text-blue-600" />
              </div>
              <CardTitle className="text-2xl">رفع أسماء الطلاب</CardTitle>
              <CardDescription className="text-base">قم برفع قائمة الطلاب والصفوف</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button className="w-full" onClick={() => setLocation('/upload')}>
                ابدأ الآن
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2" onClick={() => setLocation('/attendance')}>
            <CardHeader className="text-center">
              <div className="mx-auto bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <ClipboardCheck className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle className="text-2xl">التحضير اليومي</CardTitle>
              <CardDescription className="text-base">سجل حضور وغياب الطلاب</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button className="w-full" onClick={() => setLocation('/attendance')}>
                ابدأ الآن
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2" onClick={() => setLocation('/quick-barcode')}>
            <CardHeader className="text-center">
              <div className="mx-auto bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Zap className="w-8 h-8 text-yellow-600" />
              </div>
              <CardTitle className="text-2xl">التحضير السريع</CardTitle>
              <CardDescription className="text-base">أدخل الباركود مباشرة</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button className="w-full" onClick={() => setLocation('/quick-barcode')}>
                ابدأ الآن
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2" onClick={() => setLocation('/camera')}>
            <CardHeader className="text-center">
              <div className="mx-auto bg-cyan-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Camera className="w-8 h-8 text-cyan-600" />
              </div>
              <CardTitle className="text-2xl">التحضير بالكاميرا</CardTitle>
              <CardDescription className="text-base">امسح باركود الطالب بالكاميرا</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button className="w-full" onClick={() => setLocation('/camera')}>
                ابدأ الآن
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2" onClick={() => setLocation('/statistics')}>
            <CardHeader className="text-center">
              <div className="mx-auto bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <BarChart3 className="w-8 h-8 text-purple-600" />
              </div>
              <CardTitle className="text-2xl">الإحصائيات الشهرية</CardTitle>
              <CardDescription className="text-base">عرض تقارير الحضور والغياب</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button className="w-full" onClick={() => setLocation('/statistics')}>
                ابدأ الآن
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2" onClick={() => setLocation('/absence-report')}>
            <CardHeader className="text-center">
              <div className="mx-auto bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <AlertCircle className="w-8 h-8 text-red-600" />
              </div>
              <CardTitle className="text-2xl">تقرير الغياب اليومي</CardTitle>
              <CardDescription className="text-base">عرض وطباعة الغيابات اليومية</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button className="w-full" onClick={() => setLocation('/absence-report')}>
                ابدأ الآن
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2" onClick={() => setLocation('/print-barcodes')}>
            <CardHeader className="text-center">
              <div className="mx-auto bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Printer className="w-8 h-8 text-orange-600" />
              </div>
              <CardTitle className="text-2xl">طباعة الباركود</CardTitle>
              <CardDescription className="text-base">اطبع بطاقات الباركود للطلاب</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button className="w-full" onClick={() => setLocation('/print-barcodes')}>
                ابدأ الآن
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2" onClick={() => setLocation('/advanced-reports')}>
            <CardHeader className="text-center">
              <div className="mx-auto bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <TrendingUp className="w-8 h-8 text-indigo-600" />
              </div>
              <CardTitle className="text-2xl">التقارير المتقدمة</CardTitle>
              <CardDescription className="text-base">تحليل وتصفية سجلات الحضور</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button className="w-full" onClick={() => setLocation('/advanced-reports')}>
                ابدأ الآن
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2" onClick={() => setLocation('/admin-dashboard')}>
            <CardHeader className="text-center">
              <div className="mx-auto bg-rose-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Settings className="w-8 h-8 text-rose-600" />
              </div>
              <CardTitle className="text-2xl">لوحة تحكم المدير</CardTitle>
              <CardDescription className="text-base">إدارة شاملة للنظام</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button className="w-full" onClick={() => setLocation('/admin-dashboard')}>
                ابدأ الآن
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2" onClick={() => setLocation('/backups')}>
            <CardHeader className="text-center">
              <div className="mx-auto bg-teal-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Cloud className="w-8 h-8 text-teal-600" />
              </div>
              <CardTitle className="text-2xl">النسخ الاحتياطية</CardTitle>
              <CardDescription className="text-base">إدارة النسخ الاحتياطية والاستعادة</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button className="w-full" onClick={() => setLocation('/backups')}>
                ابدأ الآن
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
