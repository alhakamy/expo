import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Camera, CheckCircle2, AlertCircle, X, Loader2 } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLocation } from 'wouter';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { trpc } from '@/lib/trpc';

export default function CameraAttendance() {
  const [, setLocation] = useLocation();
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [scannedStudents, setScannedStudents] = useState<Record<number, 'present' | 'absent'>>({});
  const [scannerActive, setScannerActive] = useState(false);
  const [scannerError, setScannerError] = useState<string | null>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [today] = useState(new Date().toISOString().split('T')[0]);
  const [lastScannedBarcode, setLastScannedBarcode] = useState<string>('');
  const [barcodeInput, setBarcodeInput] = useState<string>('');
  const [savingStudents, setSavingStudents] = useState<number[]>([]);
  const [isSavingAll, setIsSavingAll] = useState(false);
  
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);
  const qrReaderRef = useRef<HTMLDivElement>(null);
  const barcodeInputRef = useRef<HTMLInputElement>(null);

  // API calls
  const { data: students = [] } = trpc.students.list.useQuery();
  const { data: todayAttendance = [] } = trpc.attendance.getByDate.useQuery(today);
  const recordAttendanceMutation = trpc.attendance.record.useMutation();

  const classes = Array.from(new Set(students.map(s => s.class)));
  const classStudents = selectedClass ? students.filter(s => s.class === selectedClass) : [];

  // Load today's attendance
  useEffect(() => {
    if (!selectedClass) {
      setScannedStudents({});
      return;
    }

    const attendanceRecord: Record<number, 'present' | 'absent'> = {};
    classStudents.forEach(student => {
      const record = todayAttendance.find(r => r.studentId === student.id);
      const status = record?.status === 'present' ? 'present' : 'absent';
      attendanceRecord[student.id] = status;
    });
    setScannedStudents(attendanceRecord);
  }, [selectedClass, classStudents, todayAttendance]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopScanner();
    };
  }, []);

  const playSuccessSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = 800;
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.1);
    } catch (err) {
      console.error('Error playing sound:', err);
    }
  };

  const startScanner = async () => {
    if (!qrReaderRef.current) return;

    try {
      setScannerError(null);
      setScannerActive(true);

      if (scannerRef.current) {
        try {
          scannerRef.current.clear();
        } catch (e) {
          console.log('Error clearing scanner:', e);
        }
      }

      scannerRef.current = new Html5QrcodeScanner(
        'qr-reader',
        {
          fps: 15,
          qrbox: { width: 250, height: 250 },
          showTorchButtonIfSupported: true,
          aspectRatio: 1.0,
          disableFlip: false,
          rememberLastUsedCamera: true
        },
        false
      );

      scannerRef.current.render(
        (decodedText) => {
          handleBarcodeScanned(decodedText);
        },
        (error) => {
          if (!error.includes('NotFoundError') && !error.includes('NotFoundException')) {
            console.log('QR Code scanning error:', error);
          }
        }
      );
    } catch (error: any) {
      console.error('Error starting scanner:', error);
      setScannerError(`خطأ في فتح الكاميرا: ${error.message || 'حاول مرة أخرى'}`);
      setScannerActive(false);
    }
  };

  const stopScanner = () => {
    if (scannerRef.current) {
      try {
        scannerRef.current.clear();
      } catch (e) {
        console.log('Error stopping scanner:', e);
      }
      scannerRef.current = null;
    }
    setScannerActive(false);
    setScannerError(null);
  };

  const handleBarcodeInput = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const barcode = barcodeInput.trim().toLowerCase();
      if (barcode) {
        handleBarcodeScanned(barcode);
        setBarcodeInput('');
        barcodeInputRef.current?.focus();
      }
    }
  };

  const handleBarcodeScanned = async (barcode: string) => {
    const trimmedBarcode = barcode.trim();

    // منع المسح المتكرر
    if (trimmedBarcode === lastScannedBarcode) {
      return;
    }

    setLastScannedBarcode(trimmedBarcode);
    setTimeout(() => setLastScannedBarcode(''), 500);

    const student = classStudents.find(s => s.barcode === trimmedBarcode);

    if (student) {
      playSuccessSound();
      
      // تحديث محلي
      const currentStatus = scannedStudents[student.id] || 'absent';
      const newStatus = currentStatus === 'present' ? 'absent' : 'present';
      
      setScannedStudents(prev => ({
        ...prev,
        [student.id]: newStatus
      }));

      // حفظ فوري
      try {
        setSavingStudents(prev => [...prev, student.id]);
        
        await recordAttendanceMutation.mutateAsync({
          studentId: student.id,
          date: today,
          status: newStatus,
        });

        setSavingStudents(prev => prev.filter(id => id !== student.id));
        
        const statusText = newStatus === 'present' ? 'حاضر' : 'غائب';
        setMessage({ 
          type: 'success', 
          text: `${student.name} - ${statusText}` 
        });
        setTimeout(() => setMessage(null), 2000);
      } catch (error) {
        console.error('Error saving attendance:', error);
        setSavingStudents(prev => prev.filter(id => id !== student.id));
        setMessage({ 
          type: 'error', 
          text: 'خطأ في حفظ البيانات' 
        });
        setTimeout(() => setMessage(null), 2000);
      }
    } else {
      setMessage({ type: 'error', text: 'الباركود غير معروف' });
      setTimeout(() => setMessage(null), 2000);
    }
  };

  const toggleAttendance = async (studentId: number) => {
    try {
      const currentStatus = scannedStudents[studentId] || 'absent';
      const newStatus = currentStatus === 'present' ? 'absent' : 'present';
      
      setScannedStudents(prev => ({
        ...prev,
        [studentId]: newStatus
      }));

      setSavingStudents(prev => [...prev, studentId]);
      
      await recordAttendanceMutation.mutateAsync({
        studentId: studentId,
        date: today,
        status: newStatus,
      });

      setSavingStudents(prev => prev.filter(id => id !== studentId));
      
      setMessage({ 
        type: 'success', 
        text: 'تم تحديث الحضور' 
      });
      setTimeout(() => setMessage(null), 2000);
    } catch (error) {
      console.error('Error:', error);
      setSavingStudents(prev => prev.filter(id => id !== studentId));
      setMessage({ 
        type: 'error', 
        text: 'خطأ في حفظ البيانات' 
      });
      setTimeout(() => setMessage(null), 2000);
    }
  };

  const saveAttendance = async () => {
    if (!selectedClass) return;

    try {
      setIsSavingAll(true);
      for (const student of classStudents) {
        const status = scannedStudents[student.id] || 'absent';
        await recordAttendanceMutation.mutateAsync({
          studentId: student.id,
          date: today,
          status: status,
        });
      }

      setMessage({ type: 'success', text: 'تم حفظ التحضير بنجاح!' });
      setTimeout(() => setMessage(null), 3000);
    } catch (error) {
      console.error('Error saving attendance:', error);
      setMessage({ type: 'error', text: 'حدث خطأ في حفظ التحضير' });
      setTimeout(() => setMessage(null), 3000);
    } finally {
      setIsSavingAll(false);
    }
  };

  const presentCount = Object.values(scannedStudents).filter(s => s === 'present').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <Button 
          variant="ghost" 
          onClick={() => setLocation('/')} 
          className="mb-6 flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          العودة للرئيسية
        </Button>

        <Card className="mb-6 shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl md:text-3xl flex items-center gap-3">
              <Camera className="w-6 h-6 md:w-8 md:h-8 text-blue-600" />
              التحضير بالكاميرا
            </CardTitle>
            <CardDescription className="text-sm md:text-base">
              امسح باركود الطالب بكاميرا الجوال أو أدخله يدوياً
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">اختر الصف</label>
              <select
                value={selectedClass}
                onChange={(e) => {
                  setSelectedClass(e.target.value);
                  stopScanner();
                }}
                className="w-full p-3 border-2 border-gray-300 rounded-lg text-sm md:text-base focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">-- اختر الصف --</option>
                {classes.map(cls => (
                  <option key={cls} value={cls}>{cls}</option>
                ))}
              </select>
            </div>

            {message && (
              <Alert className={`${message.type === 'success' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                {message.type === 'success' ? (
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-red-600" />
                )}
                <AlertDescription className={message.type === 'success' ? 'text-green-800' : 'text-red-800'}>
                  {message.text}
                </AlertDescription>
              </Alert>
            )}

            {scannerError && (
              <Alert className="bg-red-50 border-red-200">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  {scannerError}
                </AlertDescription>
              </Alert>
            )}

            {selectedClass && (
              <>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">أدخل رقم الباركود يدوياً</label>
                    <input
                      ref={barcodeInputRef}
                      type="text"
                      value={barcodeInput}
                      onChange={(e) => setBarcodeInput(e.target.value)}
                      onKeyDown={handleBarcodeInput}
                      placeholder="مثال: stu1 - اضغط Enter"
                      className="w-full p-3 border-2 border-gray-300 rounded-lg text-sm md:text-base focus:outline-none focus:ring-2 focus:ring-blue-500"
                      autoFocus
                    />
                  </div>

                  <div className="flex gap-2">
                    {!scannerActive ? (
                      <Button 
                        onClick={startScanner} 
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-sm md:text-base"
                      >
                        <Camera className="w-4 h-4 ml-2" />
                        فتح الكاميرا
                      </Button>
                    ) : (
                      <Button 
                        onClick={stopScanner} 
                        className="flex-1 bg-red-600 hover:bg-red-700 text-sm md:text-base"
                      >
                        <X className="w-4 h-4 ml-2" />
                        إيقاف الكاميرا
                      </Button>
                    )}
                  </div>
                </div>

                {scannerActive && (
                  <div className="space-y-2">
                    <p className="text-sm text-gray-600 text-center font-semibold">
                      وجّه الكاميرا نحو الباركود
                    </p>
                    <div
                      id="qr-reader"
                      ref={qrReaderRef}
                      className="w-full rounded-lg overflow-hidden border-4 border-blue-400 bg-black"
                      style={{ minHeight: '300px', maxHeight: '400px' }}
                    />
                  </div>
                )}

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  <h3 className="font-semibold text-lg sticky top-0 bg-white py-2 z-10">
                    الطلاب ({presentCount}/{classStudents.length})
                  </h3>
                  {classStudents.length > 0 ? (
                    classStudents.map(student => {
                      const status = scannedStudents[student.id] || 'absent';
                      const isSaving = savingStudents.includes(student.id);
                      return (
                        <div
                          key={student.id}
                          className={`flex items-center justify-between p-3 rounded-lg border-2 text-sm md:text-base transition-all ${
                            status === 'present'
                              ? 'bg-green-50 border-green-300'
                              : 'bg-red-50 border-red-300'
                          } ${isSaving ? 'opacity-60' : ''}`}
                        >
                          <span className="font-medium flex-1">{student.name}</span>
                          <div className="flex items-center gap-2">
                            {isSaving ? (
                              <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
                            ) : (
                              <button
                                onClick={() => toggleAttendance(student.id)}
                                className={`px-3 py-1 rounded text-xs md:text-sm font-medium transition-colors ${
                                  status === 'present'
                                    ? 'bg-green-500 text-white hover:bg-green-600'
                                    : 'bg-red-500 text-white hover:bg-red-600'
                                }`}
                              >
                                {status === 'present' ? 'حاضر' : 'غائب'}
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      لا توجد طلاب في هذا الصف
                    </div>
                  )}
                </div>

                <Button
                  onClick={saveAttendance}
                  className="w-full bg-green-600 hover:bg-green-700 text-sm md:text-base"
                  disabled={isSavingAll || savingStudents.length > 0}
                >
                  {isSavingAll ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      جاري الحفظ...
                    </>
                  ) : (
                    'حفظ التحضير'
                  )}
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
