import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowRight, Download, Printer } from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import JsBarcode from 'jsbarcode';

declare global {
  interface Window {
    open(url?: string, target?: string, features?: string): Window | null;
  }
}

interface Student {
  id: string;
  name: string;
  className: string;
  barcode: string;
}

export default function PrintBarcodes() {
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [printType, setPrintType] = useState<'all' | 'class' | 'student'>('all');
  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const barcodeRef = useRef<HTMLDivElement>(null);

  // تحميل البيانات من localStorage
  const loadStudents = () => {
    const stored = localStorage.getItem('students');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setStudents(parsed);
      } catch (error) {
        console.error('خطأ في تحميل البيانات:', error);
      }
    }
  };

  const handleLoadData = () => {
    loadStudents();
  };

  const getClassNames = () => {
    const classSet = new Set(students.map(s => s.className));
    return Array.from(classSet).sort();
  };

  const getStudentsForPrint = () => {
    if (printType === 'all') {
      return students;
    } else if (printType === 'class' && selectedClass) {
      return students.filter(s => s.className === selectedClass);
    } else if (printType === 'student' && selectedStudent) {
      return students.filter(s => s.id === selectedStudent);
    }
    return [];
  };

  const generatePDF = async () => {
    const studentsToPrint = getStudentsForPrint();
    if (studentsToPrint.length === 0) {
      alert('يرجى اختيار طلاب للطباعة');
      return;
    }

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    let yPosition = 10;
    let xPosition = 10;
    const cardWidth = 80;
    const cardHeight = 100;
    const margin = 5;

    for (let i = 0; i < studentsToPrint.length; i++) {
      const student = studentsToPrint[i];

      // التحقق من الحاجة إلى صفحة جديدة
      if (yPosition + cardHeight > pageHeight - 10) {
        pdf.addPage();
        yPosition = 10;
        xPosition = 10;
      }

      // رسم الإطار
      pdf.setDrawColor(200);
      pdf.rect(xPosition, yPosition, cardWidth, cardHeight);

      // إضافة اسم الطالب
      pdf.setFontSize(10);
      pdf.text(`اسم: ${student.name}`, xPosition + 5, yPosition + 10);

      // إضافة الصف
      pdf.setFontSize(9);
      pdf.text(`الصف: ${student.className}`, xPosition + 5, yPosition + 20);

      // إنشاء الباركود
      const barcodeCanvas = document.createElement('canvas');
      JsBarcode(barcodeCanvas, student.barcode, {
        format: 'CODE128',
        width: 2,
        height: 50,
        displayValue: false
      });

      const barcodeImage = barcodeCanvas.toDataURL('image/png');
      pdf.addImage(barcodeImage, 'PNG', xPosition + 5, yPosition + 28, 70, 40);

      // إضافة رقم الباركود
      pdf.setFontSize(8);
      pdf.text(student.barcode, xPosition + 5, yPosition + 72);

      // الانتقال إلى الموضع التالي
      xPosition += cardWidth + margin;
      if (xPosition + cardWidth > pageWidth) {
        xPosition = 10;
        yPosition += cardHeight + margin;
      }
    }

    // حفظ الملف
    const fileName = `barcodes_${new Date().toISOString().split('T')[0]}.pdf`;
    pdf.save(fileName);
  };

  const handlePrint = async () => {
    const studentsToPrint = getStudentsForPrint();
    if (studentsToPrint.length === 0) {
      alert('يرجى اختيار طلاب للطباعة');
      return;
    }

    // إنشاء نافذة طباعة جديدة
    const printWindow = window.open('', '', 'height=600,width=800');
    if (!printWindow) {
      alert('يرجى السماح بفتح نوافذ منفثقة');
      return;
    }

    let html = `
      <html>
        <head>
          <title>طباعة الباركود</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 10px; direction: rtl; }
            .barcode-card { 
              display: inline-block; 
              border: 1px solid #ccc; 
              padding: 10px; 
              margin: 5px;
              text-align: center;
              width: 200px;
            }
            .barcode-card img { max-width: 100%; }
            .barcode-card p { margin: 5px 0; font-size: 12px; }
            @media print {
              body { margin: 0; }
              .barcode-card { page-break-inside: avoid; }
            }
          </style>
        </head>
        <body>
    `;

    for (const student of studentsToPrint) {
      const barcodeCanvas = document.createElement('canvas');
      JsBarcode(barcodeCanvas, student.barcode, {
        format: 'CODE128',
        width: 2,
        height: 50,
        displayValue: false
      });

      const barcodeImage = barcodeCanvas.toDataURL('image/png');
      html += `
        <div class="barcode-card">
          <p><strong>${student.name}</strong></p>
          <p>${student.className}</p>
          <img src="${barcodeImage}" alt="barcode">
          <p>${student.barcode}</p>
        </div>
      `;
    }

    html += `
        </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.print();
  };

  const classNames = getClassNames();
  const classStudents = selectedClass ? students.filter(s => s.className === selectedClass) : [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* رأس الصفحة */}
        <div className="mb-8 text-right">
          <div className="flex items-center justify-end gap-2 mb-2">
            <h1 className="text-4xl font-bold text-gray-800">طباعة الباركود</h1>
            <Printer className="w-10 h-10 text-blue-600" />
          </div>
          <p className="text-gray-600">إنشاء وطباعة بطاقات الباركود للطلاب</p>
        </div>

        {/* زر تحميل البيانات */}
        <Card className="mb-6 p-6 bg-white shadow-lg">
          <Button
            onClick={handleLoadData}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            تحميل بيانات الطلاب
          </Button>
        </Card>

        {students.length > 0 && (
          <>
            {/* خيارات الطباعة */}
            <Card className="mb-6 p-6 bg-white shadow-lg">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 text-right">خيارات الطباعة</h2>

              {/* نوع الطباعة */}
              <div className="mb-6">
                <label className="block text-right text-gray-700 font-semibold mb-2">
                  نوع الطباعة
                </label>
                <div className="flex gap-4 justify-end">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      value="all"
                      checked={printType === 'all'}
                      onChange={(e) => setPrintType(e.target.value as 'all' | 'class' | 'student')}
                    />
                    <span>جميع الطلاب</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      value="class"
                      checked={printType === 'class'}
                      onChange={(e) => setPrintType(e.target.value as 'all' | 'class' | 'student')}
                    />
                    <span>فصل واحد</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      value="student"
                      checked={printType === 'student'}
                      onChange={(e) => setPrintType(e.target.value as 'all' | 'class' | 'student')}
                    />
                    <span>طالب واحد</span>
                  </label>
                </div>
              </div>

              {/* اختيار الفصل */}
              {printType === 'class' && (
                <div className="mb-6">
                  <label className="block text-right text-gray-700 font-semibold mb-2">
                    اختر الفصل
                  </label>
                  <Select value={selectedClass} onValueChange={setSelectedClass}>
                    <SelectTrigger className="w-full text-right">
                      <SelectValue placeholder="اختر الفصل" />
                    </SelectTrigger>
                    <SelectContent>
                      {classNames.map((className) => (
                        <SelectItem key={className} value={className}>
                          {className}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* اختيار الطالب */}
              {printType === 'student' && (
                <div className="mb-6">
                  <label className="block text-right text-gray-700 font-semibold mb-2">
                    اختر الطالب
                  </label>
                  <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                    <SelectTrigger className="w-full text-right">
                      <SelectValue placeholder="اختر الطالب" />
                    </SelectTrigger>
                    <SelectContent>
                      {students.map((student) => (
                        <SelectItem key={student.id} value={student.id}>
                          {student.name} - {student.className}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* أزرار الطباعة */}
              <div className="flex gap-4 justify-end">
                <Button
                  onClick={generatePDF}
                  className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  تحميل PDF
                </Button>
                <Button
                  onClick={handlePrint}
                  className="bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2"
                >
                  <Printer className="w-4 h-4" />
                  طباعة
                </Button>
              </div>
            </Card>

            {/* معلومات الطباعة */}
            <Card className="p-6 bg-white shadow-lg">
              <h3 className="text-xl font-bold text-gray-800 mb-4 text-right">معلومات الطباعة</h3>
              <div className="text-right space-y-2 text-gray-700">
                <p>
                  <strong>عدد الطلاب المراد طباعتهم:</strong> {getStudentsForPrint().length}
                </p>
                {printType === 'class' && selectedClass && (
                  <p>
                    <strong>الفصل المختار:</strong> {selectedClass}
                  </p>
                )}
                {printType === 'student' && selectedStudent && (
                  <p>
                    <strong>الطالب المختار:</strong>{' '}
                    {students.find(s => s.id === selectedStudent)?.name}
                  </p>
                )}
              </div>
            </Card>
          </>
        )}

        {/* زر العودة */}
        <div className="mt-8 flex justify-end">
          <a href="/" className="flex items-center gap-2 text-blue-600 hover:text-blue-800 font-semibold">
            <ArrowRight className="w-5 h-5" />
            العودة للرئيسية
          </a>
        </div>
      </div>
    </div>
  );
}
