import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Users, TrendingUp, Calendar, BarChart3, Download, AlertCircle } from "lucide-react";
import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";

interface DashboardStats {
  totalStudents: number;
  totalClasses: number;
  averageAttendance: number;
  todayAttendance: number;
  todayAbsence: number;
  monthlyAttendanceRate: number;
}

export default function AdminDashboard() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // API calls
  const { data: students = [] } = trpc.students.list.useQuery();
  const { data: attendanceData = [] } = trpc.attendance.getByDate.useQuery(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    try {
      setLoading(true);
      
      // Calculate statistics
      const uniqueClasses = new Set(students.map(s => s.class)).size;
      const todayRecords = attendanceData.filter(a => a.status === 'present').length;
      const todayAbsent = students.length - todayRecords;
      
      // Calculate average attendance for the month
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      const monthlyRecords = attendanceData.filter(a => {
        const date = new Date(a.date);
        return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
      });
      
      const monthlyAttendanceRate = students.length > 0 
        ? Math.round((monthlyRecords.filter(r => r.status === 'present').length / (monthlyRecords.length || 1)) * 100)
        : 0;

      const averageAttendance = students.length > 0
        ? Math.round((todayRecords / students.length) * 100)
        : 0;

      setStats({
        totalStudents: students.length,
        totalClasses: uniqueClasses,
        averageAttendance,
        todayAttendance: todayRecords,
        todayAbsence: todayAbsent,
        monthlyAttendanceRate
      });
      
      setError(null);
    } catch (err) {
      console.error('Error calculating statistics:', err);
      setError('حدث خطأ في حساب الإحصائيات');
    } finally {
      setLoading(false);
    }
  }, [students, attendanceData]);

  const handleBackupToCloud = async () => {
    try {
      setLoading(true);
      // This will be implemented with Google Drive integration
      alert('سيتم إضافة النسخ الاحتياطية السحابية قريباً');
    } catch (err) {
      console.error('Error backing up to cloud:', err);
      setError('فشل النسخ الاحتياطي');
    } finally {
      setLoading(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-xl text-gray-600">يرجى تسجيل الدخول أولاً</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <Button
          variant="outline"
          onClick={() => setLocation('/')}
          className="mb-6 flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          العودة
        </Button>

        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">لوحة تحكم المدير</h1>
          <p className="text-gray-600">إدارة شاملة لنظام التحضير الإلكتروني</p>
        </div>

        {error && (
          <Alert className="mb-6 bg-red-50 border-red-200">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              {error}
            </AlertDescription>
          </Alert>
        )}

        {loading ? (
          <div className="text-center py-12">
            <p className="text-gray-600">جاري تحميل الإحصائيات...</p>
          </div>
        ) : stats ? (
          <>
            {/* Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {/* Total Students */}
              <Card className="shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Users className="w-5 h-5 text-blue-600" />
                    إجمالي الطلاب
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-blue-600">{stats.totalStudents}</div>
                  <p className="text-sm text-gray-500 mt-2">عدد الطلاب المسجلين</p>
                </CardContent>
              </Card>

              {/* Total Classes */}
              <Card className="shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <BarChart3 className="w-5 h-5 text-green-600" />
                    إجمالي الفصول
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-green-600">{stats.totalClasses}</div>
                  <p className="text-sm text-gray-500 mt-2">عدد الفصول الدراسية</p>
                </CardContent>
              </Card>

              {/* Today Attendance */}
              <Card className="shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Calendar className="w-5 h-5 text-purple-600" />
                    الحضور اليوم
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-purple-600">{stats.averageAttendance}%</div>
                  <p className="text-sm text-gray-500 mt-2">{stats.todayAttendance} حاضر / {stats.todayAbsence} غائب</p>
                </CardContent>
              </Card>

              {/* Monthly Attendance Rate */}
              <Card className="shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <TrendingUp className="w-5 h-5 text-orange-600" />
                    معدل الحضور الشهري
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-orange-600">{stats.monthlyAttendanceRate}%</div>
                  <p className="text-sm text-gray-500 mt-2">متوسط الحضور للشهر الحالي</p>
                </CardContent>
              </Card>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Backup to Cloud */}
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Download className="w-5 h-5 text-cyan-600" />
                    النسخ الاحتياطية السحابية
                  </CardTitle>
                  <CardDescription>رفع البيانات إلى Google Drive</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    onClick={handleBackupToCloud}
                    disabled={loading}
                    className="w-full bg-cyan-600 hover:bg-cyan-700"
                  >
                    {loading ? 'جاري النسخ...' : 'بدء النسخ الاحتياطي'}
                  </Button>
                  <p className="text-sm text-gray-500 mt-4">
                    تأكد من ربط حسابك بـ Google Drive لتفعيل النسخ الاحتياطية التلقائية
                  </p>
                </CardContent>
              </Card>

              {/* Export Data */}
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-indigo-600" />
                    تصدير البيانات
                  </CardTitle>
                  <CardDescription>تحميل التقارير الشاملة</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    variant="outline"
                    className="w-full"
                  >
                    تحميل التقرير الشامل
                  </Button>
                  <p className="text-sm text-gray-500 mt-4">
                    تحميل جميع البيانات والإحصائيات بصيغة Excel
                  </p>
                </CardContent>
              </Card>
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
}
