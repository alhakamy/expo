import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Upload, FileSpreadsheet, CheckCircle, AlertCircle, Trash2, AlertTriangle, Loader2 } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import * as XLSX from 'xlsx';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';

interface Student {
  name: string;
  class: string;
  barcode: string;
}

let barcodeCounter = 1;

function generateBarcode(): string {
  const barcode = `stu${barcodeCounter}`;
  barcodeCounter++;
  return barcode;
}

export default function UploadStudents() {
  const [, setLocation] = useLocation();
  const [file, setFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<'success' | 'error' | 'added' | 'uploading' | null>(null);
  const [manualName, setManualName] = useState('');
  const [manualClass, setManualClass] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [pendingStudents, setPendingStudents] = useState<Student[] | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // API calls
  const { data: students = [], refetch: refetchStudents } = trpc.students.list.useQuery();
  const addStudentMutation = trpc.students.add.useMutation();
  const addBulkMutation = trpc.students.addBulk.useMutation();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (uploadedFile) {
      setFile(uploadedFile);
      const reader = new FileReader();

      reader.onload = (event) => {
        try {
          const data = event.target?.result;
          let parsedStudents: Student[] = [];

          if (uploadedFile.name.endsWith('.xlsx') || uploadedFile.name.endsWith('.xls')) {
            const workbook = XLSX.read(data, { type: 'array' });
            const sheetName = workbook.SheetNames.includes('Sheet2') ? 'Sheet2' : workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const json = XLSX.utils.sheet_to_json(worksheet, { header: 1, raw: false });

            let nameColIndex = -1;
            let classColIndex = -1;

            if (json.length > 0) {
              const headerRow = json[0] as any[];
              for (let i = 0; i < headerRow.length; i++) {
                const cellValue = String(headerRow[i]).toLowerCase().trim();
                if (cellValue.includes('اسم') || cellValue.includes('name')) {
                  nameColIndex = i;
                }
                if (cellValue.includes('صف') || cellValue.includes('class')) {
                  classColIndex = i;
                }
              }
            }

            if (nameColIndex === -1) nameColIndex = 0;
            if (classColIndex === -1) classColIndex = 1;

            const startIndex = (json[0] && (String((json[0] as any[])[nameColIndex]).includes('اسم') || String((json[0] as any[])[nameColIndex]).includes('name'))) ? 1 : 0;

            for (let i = startIndex; i < json.length; i++) {
              const row = json[i] as any[];
              if (row && row.length > Math.max(nameColIndex, classColIndex) && row[nameColIndex] && row[classColIndex]) {
                parsedStudents.push({
                  name: String(row[nameColIndex]).trim(),
                  class: String(row[classColIndex]).trim(),
                  barcode: generateBarcode()
                });
              }
            }
          }

          if (parsedStudents.length > 0) {
            if (students.length > 0) {
              setPendingStudents(parsedStudents);
              setShowDeleteConfirm(true);
            } else {
              handleUploadStudents(parsedStudents);
            }
          } else {
            setUploadStatus('error');
          }
        } catch (error) {
          console.error('Error parsing file:', error);
          setUploadStatus('error');
        }
      };

      reader.readAsArrayBuffer(uploadedFile);
    }
  };

  const handleUploadStudents = async (studentsToUpload: Student[]) => {
    setUploadStatus('uploading');
    try {
      await addBulkMutation.mutateAsync(studentsToUpload);
      await refetchStudents();
      setUploadStatus('success');
      setPendingStudents(null);
      setShowDeleteConfirm(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Error uploading students:', error);
      setUploadStatus('error');
    }
  };

  const handleConfirmDelete = () => {
    if (pendingStudents) {
      handleUploadStudents(pendingStudents);
    }
  };

  const handleCancelDelete = () => {
    setShowDeleteConfirm(false);
    setPendingStudents(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleManualAdd = async () => {
    if (manualName.trim() && manualClass.trim()) {
      try {
        await addStudentMutation.mutateAsync({
          name: manualName.trim(),
          class: manualClass.trim(),
          barcode: generateBarcode(),
        });
        await refetchStudents();
        setManualName('');
        setManualClass('');
        setUploadStatus('added');
      } catch (error) {
        console.error('Error adding student:', error);
        setUploadStatus('error');
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-4xl mx-auto">
        <Button variant="ghost" onClick={() => setLocation('/')} className="mb-6">
          <ArrowLeft className="ml-2" />
          العودة للرئيسية
        </Button>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-3xl flex items-center gap-3">
              <Upload className="w-8 h-8 text-blue-600" />
              رفع أسماء الطلاب
            </CardTitle>
            <CardDescription className="text-base">
              قم برفع ملف Excel يحتوي على أسماء الطلاب والصفوف، أو أضف الطلاب يدويًا
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {showDeleteConfirm && pendingStudents && (
              <Alert className="bg-yellow-50 border-yellow-200">
                <AlertTriangle className="h-5 w-5 text-yellow-600" />
                <AlertDescription className="text-yellow-800 mt-2">
                  <div className="font-semibold mb-3">تنبيه: سيتم حذف البيانات القديمة!</div>
                  <p className="mb-4">
                    لديك حالياً {students.length} طالب في النظام. عند المتابعة، سيتم حذفهم جميعاً واستبدالهم بـ {pendingStudents.length} طالب من الملف الجديد.
                  </p>
                  <div className="flex gap-3">
                    <Button 
                      onClick={handleConfirmDelete}
                      className="bg-red-600 hover:bg-red-700 text-white"
                      disabled={addBulkMutation.isPending}
                    >
                      {addBulkMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin mr-2" />
                          جاري الرفع...
                        </>
                      ) : (
                        'نعم، احذف وحمّل البيانات الجديدة'
                      )}
                    </Button>
                    <Button 
                      onClick={handleCancelDelete}
                      variant="outline"
                      disabled={addBulkMutation.isPending}
                    >
                      إلغاء
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {uploadStatus === 'success' && !showDeleteConfirm && (
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  تم رفع {students.length} طالب بنجاح!
                </AlertDescription>
              </Alert>
            )}

            {uploadStatus === 'error' && (
              <Alert className="bg-red-50 border-red-200">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  حدث خطأ في قراءة الملف. تأكد من أن الملف بصيغة Excel صحيحة.
                </AlertDescription>
              </Alert>
            )}

            {uploadStatus === 'added' && (
              <Alert className="bg-blue-50 border-blue-200">
                <CheckCircle className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-800">
                  تمت إضافة الطالب بنجاح!
                </AlertDescription>
              </Alert>
            )}

            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
              <FileSpreadsheet className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <Label htmlFor="file-upload" className="cursor-pointer">
                <div className="text-lg font-medium text-gray-700 mb-2">
                  اسحب الملف هنا أو انقر للاختيار
                </div>
                <div className="text-sm text-gray-500 mb-4">
                  صيغة Excel (اسم الطالب، الصف)
                </div>
                <Input
                  ref={fileInputRef}
                  id="file-upload"
                  type="file"
                  accept=".xlsx, .xls"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Button type="button" variant="outline">
                  اختر ملف
                </Button>
              </Label>
              {file && (
                <div className="mt-4 text-sm text-gray-600">
                  الملف المحدد: {file.name}
                </div>
              )}
            </div>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-2 text-gray-500">أو</span>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold">إضافة طالب يدويًا</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="student-name">اسم الطالب</Label>
                  <Input
                    id="student-name"
                    value={manualName}
                    onChange={(e) => setManualName(e.target.value)}
                    placeholder="أدخل اسم الطالب"
                  />
                </div>
                <div>
                  <Label htmlFor="student-class">الصف</Label>
                  <Input
                    id="student-class"
                    value={manualClass}
                    onChange={(e) => setManualClass(e.target.value)}
                    placeholder="مثال: الصف الأول"
                  />
                </div>
              </div>
              <Button 
                onClick={handleManualAdd} 
                className="w-full"
                disabled={addStudentMutation.isPending}
              >
                {addStudentMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    جاري الإضافة...
                  </>
                ) : (
                  'إضافة الطالب'
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {students.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>الطلاب المسجلون ({students.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-h-96 overflow-y-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">#</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">اسم الطالب</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">الصف</th>
                      <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">الباركود</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {students.map((student, index) => (
                      <tr key={student.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3 text-sm text-gray-600">{index + 1}</td>
                        <td className="px-4 py-3 text-sm font-medium text-gray-900">{student.name}</td>
                        <td className="px-4 py-3 text-sm text-gray-600">{student.class}</td>
                        <td className="px-4 py-3 text-sm text-gray-600 font-mono">{student.barcode}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
