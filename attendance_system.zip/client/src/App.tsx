import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useState, useEffect } from "react";
import Home from "./pages/Home";
import UploadStudents from "./pages/UploadStudents";
import DailyAttendance from "./pages/DailyAttendance";
import MonthlyStatistics from "./pages/MonthlyStatistics";
import CameraAttendance from "./pages/CameraAttendance";
import DailyAbsenceReport from "./pages/DailyAbsenceReport";
import PrintBarcodes from "./pages/PrintBarcodes";
import AdvancedReports from "./pages/AdvancedReports";
import QuickBarcode from "./pages/QuickBarcode";
import AdminDashboard from "./pages/AdminDashboard";
import Backups from "./pages/Backups";

interface Student {
  id: string;
  name: string;
  class: string;
  barcode: string;
}

interface AttendanceRecord {
  date: string;
  classname: string;
  attendance: Record<string, 'present' | 'absent'>;
}

function Router({ students, setStudents, attendanceRecords, setAttendanceRecords }: any) {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/upload"} component={UploadStudents} />
      <Route path={"/attendance"} component={DailyAttendance} />
      <Route path={"/camera"} component={CameraAttendance} />
      <Route path={"/statistics"} component={() => <MonthlyStatistics students={students} attendanceRecords={attendanceRecords} />} />
      <Route path={"/absence-report"} component={() => <DailyAbsenceReport students={students} attendanceRecords={attendanceRecords} />} />
      <Route path={"/print-barcodes"} component={PrintBarcodes} />
      <Route path={"/advanced-reports"} component={AdvancedReports} />
      <Route path={"/quick-barcode"} component={QuickBarcode} />
      <Route path={"/admin-dashboard"} component={AdminDashboard} />
      <Route path={"/backups"} component={Backups} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [students, setStudents] = useState<Student[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedStudents = localStorage.getItem('students');
    const savedRecords = localStorage.getItem('attendanceRecords');
    
    if (savedStudents) {
      setStudents(JSON.parse(savedStudents));
    } else {
      // Load sample data if no saved data
      fetch('/students.json')
        .then(res => res.json())
        .then(data => setStudents(data))
        .catch(err => console.error('Error loading students:', err));
    }
    
    if (savedRecords) setAttendanceRecords(JSON.parse(savedRecords));
  }, []);

  // Save students to localStorage
  useEffect(() => {
    if (students.length > 0) {
      localStorage.setItem('students', JSON.stringify(students));
    }
  }, [students]);

  // Save attendance records to localStorage
  useEffect(() => {
    if (attendanceRecords.length > 0) {
      localStorage.setItem('attendanceRecords', JSON.stringify(attendanceRecords));
    }
  }, [attendanceRecords]);

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router students={students} setStudents={setStudents} attendanceRecords={attendanceRecords} setAttendanceRecords={setAttendanceRecords} />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
