import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, students, attendance, InsertStudent, InsertAttendance, backups, InsertBackup } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ===== Students Functions =====

export async function addStudent(userId: number, student: Omit<InsertStudent, 'userId'>) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(students).values({
    ...student,
    userId,
  });

  return result;
}

export async function getStudentsByUser(userId: number) {
  const db = await getDb();
  if (!db) {
    return [];
  }

  return await db.select().from(students).where(eq(students.userId, userId));
}

export async function deleteStudentsByUser(userId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.delete(students).where(eq(students.userId, userId));
}

export async function getStudentByBarcode(userId: number, barcode: string) {
  const db = await getDb();
  if (!db) {
    return undefined;
  }

  const result = await db.select().from(students)
    .where(and(
      eq(students.userId, userId),
      eq(students.barcode, barcode)
    ))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ===== Attendance Functions =====

export async function recordAttendance(userId: number, attendanceRecord: Omit<InsertAttendance, 'userId'>) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(attendance).values({
    ...attendanceRecord,
    userId,
  });

  return result;
}

export async function getAttendanceByDate(userId: number, date: Date) {
  const db = await getDb();
  if (!db) {
    return [];
  }

  const dateStr = date.toISOString().split('T')[0];

  return await db.select().from(attendance)
    .where(and(
      eq(attendance.userId, userId),
      eq(attendance.date, dateStr as any)
    ));
}

export async function getAttendanceByStudent(userId: number, studentId: number) {
  const db = await getDb();
  if (!db) {
    return [];
  }

  return await db.select().from(attendance)
    .where(and(
      eq(attendance.userId, userId),
      eq(attendance.studentId, studentId)
    ));
}

export async function updateAttendance(userId: number, attendanceId: number, status: 'present' | 'absent' | 'late') {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.update(attendance)
    .set({ status })
    .where(and(
      eq(attendance.id, attendanceId),
      eq(attendance.userId, userId)
    ));
}

// ===== Backup Functions =====

export async function createBackup(userId: number, backup: any) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(backups).values({
    ...backup,
    userId,
  });

  return result;
}

export async function getBackupsByUser(userId: number) {
  const db = await getDb();
  if (!db) {
    return [];
  }

  return await db.select().from(backups)
    .where(eq(backups.userId, userId))
    .orderBy(desc(backups.createdAt))
    .limit(50);
}

export async function updateBackupStatus(backupId: number, userId: number, status: 'pending' | 'completed' | 'failed', errorMessage?: string) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const updateData: any = {
    status,
  };

  if (status === 'completed') {
    updateData.completedAt = new Date();
  }

  if (errorMessage) {
    updateData.errorMessage = errorMessage;
  }

  return await db.update(backups)
    .set(updateData)
    .where(and(
      eq(backups.id, backupId),
      eq(backups.userId, userId)
    ));
}

export async function getBackupData(userId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const userStudents = await db.select().from(students).where(eq(students.userId, userId));
  const userAttendance = await db.select().from(attendance).where(eq(attendance.userId, userId));

  return {
    students: userStudents,
    attendance: userAttendance,
    backupDate: new Date().toISOString(),
  };
}
