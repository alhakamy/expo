import { getSessionCookieOptions } from "./_core/cookies";
import { COOKIE_NAME } from "@shared/const";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Students management
  students: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new Error("Unauthorized");
      return await db.getStudentsByUser(ctx.user.id);
    }),

    add: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        class: z.string().min(1),
        barcode: z.string().min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await db.addStudent(ctx.user.id, input);
      }),

    addBulk: protectedProcedure
      .input(z.array(z.object({
        name: z.string().min(1),
        class: z.string().min(1),
        barcode: z.string().min(1),
      })))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        
        // Delete old students first
        await db.deleteStudentsByUser(ctx.user.id);
        
        // Add new students
        for (const student of input) {
          await db.addStudent(ctx.user.id, student);
        }
        
        return { success: true, count: input.length };
      }),

    delete: protectedProcedure
      .input(z.number())
      .mutation(async ({ ctx, input: studentId }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        // Note: In production, add proper authorization check
        return { success: true };
      }),

    getByBarcode: protectedProcedure
      .input(z.string())
      .query(async ({ ctx, input: barcode }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await db.getStudentByBarcode(ctx.user.id, barcode);
      }),
  }),

  // Attendance management
  attendance: router({
    record: protectedProcedure
      .input(z.object({
        studentId: z.number(),
        date: z.string(),
        status: z.enum(["present", "absent", "late"]),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await db.recordAttendance(ctx.user.id, {
          studentId: input.studentId,
          date: input.date as any,
          status: input.status,
          notes: input.notes,
        });
      }),

    getByDate: protectedProcedure
      .input(z.string())
      .query(async ({ ctx, input: date }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        const dateObj = new Date(date);
        return await db.getAttendanceByDate(ctx.user.id, dateObj);
      }),

    getByStudent: protectedProcedure
      .input(z.number())
      .query(async ({ ctx, input: studentId }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await db.getAttendanceByStudent(ctx.user.id, studentId);
      }),

    update: protectedProcedure
      .input(z.object({
        attendanceId: z.number(),
        status: z.enum(["present", "absent", "late"]),
      }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await db.updateAttendance(ctx.user.id, input.attendanceId, input.status);
      }),
  }),

  // Backup management
  backup: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new Error("Unauthorized");
      return await db.getBackupsByUser(ctx.user.id);
    }),

    create: protectedProcedure
      .input(z.object({
        backupName: z.string().min(1),
        backupUrl: z.string().min(1),
        backupSize: z.number(),
        recordCount: z.number(),
        backupType: z.enum(["manual", "automatic"]),
      }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await db.createBackup(ctx.user.id, {
          ...input,
          status: "pending",
        });
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        backupId: z.number(),
        status: z.enum(["pending", "completed", "failed"]),
        errorMessage: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await db.updateBackupStatus(ctx.user.id, input.backupId, input.status, input.errorMessage);
      }),

    getData: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user) throw new Error("Unauthorized");
      return await db.getBackupData(ctx.user.id);
    }),
  }),
});

export type AppRouter = typeof appRouter;
