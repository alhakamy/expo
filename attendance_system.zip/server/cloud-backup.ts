import { getDb } from "./db";
import { students, attendance } from "../drizzle/schema";
import fs from "fs";
import path from "path";

/**
 * Cloud Backup Manager
 * Handles automatic backups to Google Drive and local storage
 */

export interface BackupData {
  timestamp: string;
  students: any[];
  attendance: any[];
  metadata: {
    totalStudents: number;
    totalRecords: number;
    backupDate: string;
  };
}

/**
 * Create a backup of all data
 */
export async function createBackup(): Promise<BackupData> {
  try {
    console.log("[Backup] Starting backup process...");

    const db = await getDb();
    if (!db) {
      throw new Error("Database not available");
    }

    // Fetch all students
    const allStudents = await db.select().from(students);
    
    // Fetch all attendance records
    const allAttendance = await db.select().from(attendance);

    const backupData: BackupData = {
      timestamp: new Date().toISOString(),
      students: allStudents,
      attendance: allAttendance,
      metadata: {
        totalStudents: allStudents.length,
        totalRecords: allAttendance.length,
        backupDate: new Date().toLocaleDateString('ar-SA')
      }
    };

    console.log("[Backup] Backup created successfully");
    return backupData;
  } catch (error) {
    console.error("[Backup] Error creating backup:", error);
    throw error;
  }
}

/**
 * Save backup to local storage
 */
export async function saveBackupLocally(backupData: BackupData): Promise<string> {
  try {
    const backupDir = path.join(process.cwd(), "backups");
    
    // Create backups directory if it doesn't exist
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }

    const filename = `backup-${new Date().toISOString().split('T')[0]}-${Date.now()}.json`;
    const filepath = path.join(backupDir, filename);

    fs.writeFileSync(filepath, JSON.stringify(backupData, null, 2));
    
    console.log(`[Backup] Local backup saved: ${filepath}`);
    return filepath;
  } catch (error) {
    console.error("[Backup] Error saving local backup:", error);
    throw error;
  }
}

/**
 * Clean old backups (keep only last 30 days)
 */
export async function cleanOldBackups(): Promise<void> {
  try {
    const backupDir = path.join(process.cwd(), "backups");
    
    if (!fs.existsSync(backupDir)) {
      return;
    }

    const files = fs.readdirSync(backupDir);
    const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);

    for (const file of files) {
      const filepath = path.join(backupDir, file);
      const stats = fs.statSync(filepath);
      
      if (stats.mtimeMs < thirtyDaysAgo) {
        fs.unlinkSync(filepath);
        console.log(`[Backup] Deleted old backup: ${file}`);
      }
    }
  } catch (error) {
    console.error("[Backup] Error cleaning old backups:", error);
  }
}

/**
 * Upload backup to Google Drive (placeholder for future implementation)
 * This requires Google Drive API credentials
 */
export async function uploadToGoogleDrive(backupData: BackupData): Promise<void> {
  try {
    console.log("[Backup] Google Drive upload feature coming soon");
    // TODO: Implement Google Drive API integration
    // This requires:
    // 1. Google Drive API credentials
    // 2. OAuth2 authentication
    // 3. File upload implementation
  } catch (error) {
    console.error("[Backup] Error uploading to Google Drive:", error);
  }
}

/**
 * Perform full backup routine
 */
export async function performFullBackup(): Promise<void> {
  try {
    console.log("[Backup] Starting full backup routine...");
    
    // Create backup
    const backupData = await createBackup();
    
    // Save locally
    await saveBackupLocally(backupData);
    
    // Clean old backups
    await cleanOldBackups();
    
    // Upload to cloud (when implemented)
    // await uploadToGoogleDrive(backupData);
    
    console.log("[Backup] Full backup routine completed successfully");
  } catch (error) {
    console.error("[Backup] Error in full backup routine:", error);
  }
}
