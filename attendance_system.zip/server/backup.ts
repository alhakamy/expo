import { getDb } from './db';
import { students as studentsTable, attendance as attendanceTable } from '../drizzle/schema';
import * as fs from 'fs';
import * as path from 'path';

const BACKUP_DIR = path.join(process.cwd(), 'backups');

// Ensure backup directory exists
if (!fs.existsSync(BACKUP_DIR)) {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

export async function createDailyBackup() {
  try {
    const timestamp = new Date().toISOString().split('T')[0];
    const backupFile = path.join(BACKUP_DIR, `backup_${timestamp}.json`);

    // Check if backup already exists for today
    if (fs.existsSync(backupFile)) {
      console.log(`Backup already exists for ${timestamp}`);
      return;
    }

    // Get all data
    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }
    const students = await db.select().from(studentsTable);
    const attendance = await db.select().from(attendanceTable);

    const backupData = {
      timestamp: new Date().toISOString(),
      date: timestamp,
      students,
      attendance,
      totalRecords: {
        students: students.length,
        attendanceRecords: attendance.length
      }
    };

    // Write backup file
    fs.writeFileSync(backupFile, JSON.stringify(backupData, null, 2));
    console.log(`Daily backup created: ${backupFile}`);

    // Keep only last 30 days of backups
    cleanOldBackups();
  } catch (error) {
    console.error('Error creating daily backup:', error);
  }
}

export function cleanOldBackups(daysToKeep: number = 30) {
  try {
    const files = fs.readdirSync(BACKUP_DIR);
    const now = Date.now();
    const maxAge = daysToKeep * 24 * 60 * 60 * 1000;

    files.forEach(file => {
      const filePath = path.join(BACKUP_DIR, file);
      const stats = fs.statSync(filePath);
      const age = now - stats.mtimeMs;

      if (age > maxAge) {
        fs.unlinkSync(filePath);
        console.log(`Deleted old backup: ${file}`);
      }
    });
  } catch (error) {
    console.error('Error cleaning old backups:', error);
  }
}

export function getBackupsList() {
  try {
    const files = fs.readdirSync(BACKUP_DIR);
    return files
      .filter(file => file.startsWith('backup_') && file.endsWith('.json'))
      .sort()
      .reverse()
      .map(file => ({
        name: file,
        date: file.replace('backup_', '').replace('.json', ''),
        path: path.join(BACKUP_DIR, file)
      }));
  } catch (error) {
    console.error('Error getting backups list:', error);
    return [];
  }
}

export function restoreBackup(backupFile: string) {
  try {
    const filePath = path.join(BACKUP_DIR, backupFile);
    
    if (!fs.existsSync(filePath)) {
      throw new Error(`Backup file not found: ${backupFile}`);
    }

    const backupData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    return backupData;
  } catch (error) {
    console.error('Error restoring backup:', error);
    throw error;
  }
}

// Schedule daily backup at midnight
export function scheduleDailyBackup() {
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(0, 0, 0, 0);

  const timeUntilMidnight = tomorrow.getTime() - now.getTime();

  setTimeout(() => {
    createDailyBackup();
    // Run every 24 hours after the first backup
    setInterval(createDailyBackup, 24 * 60 * 60 * 1000);
  }, timeUntilMidnight);

  console.log(`Daily backup scheduled for ${tomorrow.toISOString()}`);
}
