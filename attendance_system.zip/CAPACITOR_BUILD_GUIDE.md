# دليل بناء تطبيق Capacitor

هذا الدليل يشرح كيفية بناء وتشغيل تطبيق نظام التحضير الإلكتروني على أجهزة Android و iOS.

## المتطلبات

### للجميع
- Node.js و npm/pnpm
- Java Development Kit (JDK) 11 أو أحدث

### لـ Android
- Android Studio
- Android SDK (API Level 21 أو أحدث)
- Gradle

### لـ iOS
- macOS
- Xcode 12 أو أحدث
- CocoaPods

## خطوات البناء

### 1. بناء التطبيق للويب

```bash
pnpm run build
```

### 2. نسخ الأصول إلى المشاريع الأصلية

```bash
npx cap copy
```

### 3. بناء تطبيق Android

#### الخطوة 1: فتح Android Studio

```bash
cd android
# افتح المجلد في Android Studio
```

#### الخطوة 2: بناء التطبيق

في Android Studio:
1. انقر على **Build** > **Build Bundle(s)/APK(s)** > **Build APK(s)**
2. انتظر حتى ينتهي البناء
3. سيتم إنشاء ملف APK في: `android/app/build/outputs/apk/debug/app-debug.apk`

#### الخطوة 3: تثبيت على جهاز أو محاكي

```bash
npx cap run android
```

### 4. بناء تطبيق iOS

#### الخطوة 1: فتح Xcode

```bash
cd ios/App
open App.xcworkspace
```

#### الخطوة 2: بناء التطبيق

في Xcode:
1. اختر جهازك أو محاكي من القائمة العلوية
2. انقر على **Product** > **Build** أو اضغط **Cmd+B**
3. انقر على **Product** > **Run** أو اضغط **Cmd+R** لتشغيل التطبيق

#### الخطوة 3: تشغيل على جهاز

```bash
npx cap run ios
```

## الأوامر المفيدة

### تحديث الأصول بعد التغييرات

```bash
# بناء الويب وتحديث الأصول
pnpm run build
npx cap copy

# أو استخدم الأمر المختصر
npx cap sync
```

### فتح المشاريع الأصلية

```bash
# فتح Android Studio
npx cap open android

# فتح Xcode
npx cap open ios
```

### حذف وإعادة إضافة منصة

```bash
# حذف Android
rm -rf android
npx cap add android

# حذف iOS
rm -rf ios
npx cap add ios
```

## استكشاف الأخطاء

### مشكلة: "Failed to resolve module"

**الحل:**
```bash
pnpm install
pnpm run build
npx cap sync
```

### مشكلة: "Gradle build failed"

**الحل:**
1. افتح Android Studio
2. انقر على **File** > **Invalidate Caches**
3. أعد بناء المشروع

### مشكلة: "Pod install failed"

**الحل:**
```bash
cd ios/App
pod install --repo-update
```

## الميزات المدعومة

- ✓ الكاميرا (قراءة الباركود)
- ✓ التخزين المحلي (LocalStorage)
- ✓ الإشعارات (إذا تم تفعيلها)
- ✓ الوصول إلى الملفات

## الملفات المهمة

- `capacitor.config.ts` - إعدادات Capacitor
- `android/` - مشروع Android الأصلي
- `ios/App/` - مشروع iOS الأصلي
- `dist/public/` - الأصول المبنية للويب

## المزيد من المعلومات

- [Capacitor Documentation](https://capacitorjs.com/docs)
- [Android Development Guide](https://developer.android.com/docs)
- [iOS Development Guide](https://developer.apple.com/documentation/)
